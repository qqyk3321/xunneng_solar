import { NativeConsultationForm } from "@/components/native-consultation/form";
import { nativeEnabled } from "@/lib/native-consultation/config";
import { ConsultationFlow } from "@/components/consultation-flow";
import {
  regionMetadata,
  requireRegion,
  type RegionPageProps,
} from "@/lib/region-seo";

export function generateMetadata({ params }: RegionPageProps) {
  return regionMetadata(params, "consultation");
}
export default async function RegionalConsultationPage({
  params,
}: RegionPageProps) {
  const country = await requireRegion(params);
  if (nativeEnabled() && process.env.NATIVE_CONSULTATION_PRIMARY === "true") return <NativeConsultationForm key={country} country={country} />;
  return <ConsultationFlow country={country} />;
}
