import { consultationWhatsAppUrl } from "../_shared/whatsapp.ts";
import { consultationQrAttachment, PREVIEW_QR_HTML } from "../_shared/consultation-qr.ts";
import QRCode from "qrcode";
import { PNG } from "pngjs";
import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient, type SupabaseClient } from "npm:@supabase/supabase-js@2";
import { receiveSubmission, type SubmissionRow } from "./intake.ts";
import { regionalTime } from "./submission-time.ts";

type Environment = (name: string) => string | undefined;
type StoredSubmission = { id: number; received_at: string };
type DatabaseClient = SupabaseClient;

function base64Url(bytes: Uint8Array) {
  return btoa(String.fromCharCode(...bytes))
    .replaceAll("+", "-")
    .replaceAll("/", "_")
    .replaceAll("=", "");
}

async function hash(value: string) {
  const digest = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(value),
  );
  return Array.from(new Uint8Array(digest), (byte) =>
    byte.toString(16).padStart(2, "0"),
  ).join("");
}

async function createPreviewUrl(args: {
  client: DatabaseClient;
  row: SubmissionRow;
  submission: StoredSubmission;
  serviceKey: string;
  siteUrl: string;
}) {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(args.serviceKey),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const signature = new Uint8Array(
    await crypto.subtle.sign(
      "HMAC",
      key,
      new TextEncoder().encode(`consultation-preview/${args.submission.id}`),
    ),
  );
  const token = base64Url(signature);
  const { error } = await args.client
    .from("consultation_preview_tokens")
    .upsert(
      {
        tally_submission_row_id: args.submission.id,
        token_hash: await hash(token),
        // Keep old readers compatible without imposing a preview deadline.
        expires_at: "infinity",
      },
      { onConflict: "tally_submission_row_id" },
    );
  if (error) throw new Error("Preview token storage failed");
  const region = args.row.country_code === "AG" ? "antigua" : "dominica";
  return `${args.siteUrl.replace(/\/$/, "")}/${region}/submission/${token}`;
}

function formatRegionalTimestamp(
  date: Date,
  countryCode: SubmissionRow["country_code"],
): string {
  return regionalTime(date, countryCode).display;
}

function regionalSupportEmail(
  env: Environment,
  countryCode: SubmissionRow["country_code"],
): string {
  const name =
    countryCode === "AG" ? "ANTIGUA_SUPPORT_EMAIL" : "DOMINICA_SUPPORT_EMAIL";
  const email = env(name)?.trim();
  if (!email) throw new Error(`Missing ${name}`);
  return email;
}

async function sendConfirmationEmail(args: {
  client: DatabaseClient;
  env: Environment;
  row: SubmissionRow;
  submission: StoredSubmission;
  previewUrl: string;
}) {
  // A completed delivery remains completed even after Resend's 24-hour
  // idempotency window, or after an administrator changes the pricing.
  const { data: delivered, error: deliveryError } = await args.client
    .from("consultation_email_audit")
    .select("id")
    .eq("tally_submission_row_id", args.submission.id)
    .eq("status", "accepted")
    .limit(1);
  if (deliveryError) throw new Error("Email delivery lookup failed");
  if (delivered?.length) return;

  const apiKey = args.env("RESEND_API_KEY");
  const templateId = args.env("RESEND_TEMPLATE_ID");
  const from = args.env("RESEND_FROM_EMAIL");
  if (!apiKey || !templateId || !from)
    throw new Error("Resend is not configured");

  const submittedAt = new Date(args.row.submitted_at);
  const supportEmail = regionalSupportEmail(args.env, args.row.country_code);
  const idempotencyKey = `consultation-confirmation/${args.row.submission_id}`;
  const { data: audit, error: auditError } = await args.client
    .from("consultation_email_audit")
    .insert({
      tally_submission_row_id: args.submission.id,
      recipient_email: args.row.email,
      country_code: args.row.country_code,
      support_email: supportEmail,
      resend_template_id: templateId,
      resend_idempotency_key: idempotencyKey,
      status: "pending",
    })
    .select("id")
    .single();
  if (auditError || !audit) throw new Error("Email audit logging failed");

  let response: Response;
  try {
    const qrAttachment = await consultationQrAttachment(args.previewUrl, QRCode, PNG);
    response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      signal: AbortSignal.timeout(7000),
      headers: {
        authorization: `Bearer ${apiKey}`,
        "content-type": "application/json",
        "idempotency-key": idempotencyKey,
      },
      body: JSON.stringify({
        from,
        to: [args.row.email],
        reply_to: [supportEmail],
        subject: `Your consultation · ${args.row.submission_id} | Sol & Tide Energy`,
        attachments: [qrAttachment],
        template: {
          id: templateId,
          variables: {
            SUBMISSION_ID: args.row.submission_id,
            WHATSAPP_URL: consultationWhatsAppUrl(args.row.submission_id, args.env("WHATSAPP_BASE_URL") || undefined),
            RECIPIENT_NAME: args.row.name,
            RECIPIENT_EMAIL: args.row.email,
            PREVIEW_URL: args.previewUrl,
            PREVIEW_QR_HTML,
            SUPPORT_EMAIL: supportEmail,
            SUBMITTED_AT: formatRegionalTimestamp(
              submittedAt,
              args.row.country_code,
            ),

          },
        },
      }),
    });
  } catch (error) {
    await args.client
      .from("consultation_email_audit")
      .update({
        status: "failed",
        error_message:
          error instanceof Error
            ? error.message.slice(0, 2000)
            : "Network request failed",
        completed_at: new Date().toISOString(),
      })
      .eq("id", audit.id);
    throw error;
  }

  const responseText = await response.text();
  let resendEmailId: string | null = null;
  try {
    const body = JSON.parse(responseText) as { id?: unknown };
    resendEmailId = typeof body.id === "string" ? body.id : null;
  } catch {
    // Error responses are not guaranteed to be JSON.
  }
  const { error: updateError } = await args.client
    .from("consultation_email_audit")
    .update(
      response.ok
        ? {
            status: "accepted",
            resend_email_id: resendEmailId,
            resend_http_status: response.status,
            completed_at: new Date().toISOString(),
          }
        : {
            status: "failed",
            resend_http_status: response.status,
            error_message: responseText.slice(0, 2000),
            completed_at: new Date().toISOString(),
          },
    )
    .eq("id", audit.id);
  if (updateError) throw new Error("Email audit update failed");
  if (!response.ok) throw new Error(responseText || "Resend send failed");
}

Deno.serve((req: Request) =>
  receiveSubmission(
    req,
    (name) => Deno.env.get(name),
    async (row: SubmissionRow) => {
      const url = Deno.env.get("SUPABASE_URL"),
        key = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
      if (!url || !key) throw new Error("Storage is not configured");
      const client = createClient(url, key, {
        auth: { persistSession: false, autoRefreshToken: false },
        global: {
          fetch: (input, init) =>
            fetch(input, { ...init, signal: AbortSignal.timeout(7000) }),
        },
      });
      const { data, error } = await client
        .from("tally_form_submissions")
        .insert(row)
        .select("id, received_at")
        .single();
      if (!error && data?.id && data.received_at) {
        const previewUrl = await createPreviewUrl({
          client,
          row,
          submission: data,
          serviceKey: key,
          siteUrl: Deno.env.get("SITE_URL") ?? "https://www.solortide.com",
        });
        await sendConfirmationEmail({
          client,
          env: (name) => Deno.env.get(name),
          row,
          submission: data,
          previewUrl,
        });
        return { duplicate: false };
      }
      if (!error)
        throw new Error("Submission storage did not return received_at");
      if (error.code === "23505") {
        const existing = await client
          .from("tally_form_submissions")
          .select("*")
          .eq("form_id", row.form_id)
          .eq("submission_id", row.submission_id)
          .maybeSingle();
        if (!existing.error && existing.data?.id && existing.data.received_at) {
          const previewUrl = await createPreviewUrl({
            client,
            row: existing.data,
            submission: existing.data,
            serviceKey: key,
            siteUrl: Deno.env.get("SITE_URL") ?? "https://www.solortide.com",
          });
          await sendConfirmationEmail({
            client,
            env: (name) => Deno.env.get(name),
            row: existing.data,
            submission: existing.data,
            previewUrl,
          });
          return { duplicate: true };
        }
      }
      throw new Error("Submission storage failed");
    },
  ),
);
