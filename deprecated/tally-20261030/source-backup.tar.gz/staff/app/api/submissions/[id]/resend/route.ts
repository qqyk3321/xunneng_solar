import { isSubmissionId } from "@solortide/consultation-core";
import { nativeDatabase } from "@/lib/submissions/native";
import { currentStaff } from "@/lib/auth/server";
import { getRow } from "@/lib/data";
import { loadCustomerPreviewUrl } from "@/lib/submissions/server";

export const runtime = "nodejs";
export const maxDuration = 30;
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const reply = (status: string, http = 200, extra: Record<string, unknown> = {}) =>
  Response.json({ status, ...extra }, { status: http, headers: { "Cache-Control": "no-store" } });

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  // Same-origin protection complements the server's authenticated session check.
  try {
    const origin = new URL(request.headers.get("origin") || "");
    if (origin.host !== request.headers.get("host") || !["https:", "http:"].includes(origin.protocol)
      || request.headers.get("sec-fetch-site") === "cross-site") return reply("forbidden", 403);
  } catch { return reply("forbidden", 403); }
  try {
    const staff = await currentStaff();
    if (!staff || staff.profile.status !== "active") return reply("unauthorized", 401);
    const { id } = await context.params;
    if (!isSubmissionId(id)) return reply("invalid", 400);
    const text = await request.text();
    if (text.length > 512) return reply("invalid", 400);
    let input;
    try { input = JSON.parse(text); } catch { return reply("invalid", 400); }
    if (!input || typeof input !== "object" || Array.isArray(input)
      || Object.keys(input).some(key => key !== "requestId")
      || typeof input.requestId !== "string" || !uuid.test(input.requestId)) return reply("invalid", 400);
    const row = await getRow("submissions", id);
    if (!row) return reply("unavailable", 404);
    const previewUrl = await loadCustomerPreviewUrl(row);
    if (!previewUrl) return reply("unavailable", 422);
    if (row.consultation_id) {
      const { data, error } = await nativeDatabase().rpc("queue_native_consultation_resend", {
        p_id: row.consultation_id, p_request_id: input.requestId,
        p_actor_id: staff.profile.id, p_actor_email: staff.profile.email,
      });
      if (error) return reply(error.code === "PT409" ? "invalid" : "unavailable", error.code === "PT409" ? 409 : 503);
      return reply(data.status, 200, { requestId: input.requestId, retryAfter: data.retryAfter || 5 });
    }
    const base = process.env.SUPABASE_URL?.trim(), key = process.env.SUPABASE_SECRET_KEY?.trim();
    if (!base || !key) return reply("unavailable", 503);
    const response = await fetch(`${base}/functions/v1/staff-resend-consultation`, {
      method: "POST", cache: "no-store", signal: AbortSignal.timeout(20000),
      headers: { apikey: key, "content-type": "application/json" },
      body: JSON.stringify({ submissionId: id, requestId: input.requestId,
        actorId: staff.profile.id, actorEmail: staff.profile.email, previewUrl }),
    });
    const result = await response.json();
    if (!["accepted", "failed", "pending", "cooldown", "uncertain"].includes(result.status)) return reply("unavailable", 503);
    return reply(result.status, 200, {
      ...(typeof result.requestId === "string" && uuid.test(result.requestId) ? { requestId: result.requestId } : {}),
      retryAfter: Math.min(60, Math.max(0, Number(result.retryAfter) || 0)),
    });
  } catch { return reply("pending", 503, { retryAfter: 15 }); }
}
