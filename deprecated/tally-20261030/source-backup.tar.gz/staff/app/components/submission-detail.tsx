import { SubmissionEnvironment } from "./submission-environment";
import { answerEntries } from "@solortide/consultation-core";
import { getT, getLocale } from "../../lib/i18n/server";
import { translator } from "../../lib/i18n/messages";
import type { Row } from "../../lib/data";
import { formatDate, parseFilters, queryString, record, safeUrl, type Params } from "../../lib/query";
import { consumptionProfileLabel, validMonthlyKwh } from "../../lib/submissions/presentation";
import { loadSubmissionEstimate } from "../../lib/submissions/estimate";
import { loadCustomerPreviewUrl } from "../../lib/submissions/server";
import { Back } from "./shell";
import { ArrowLeft } from "lucide-react";
import { WorkspaceLink } from "./workspace-navigation";
import { contactReturnHref } from "../../lib/contacts/query";
import { CopyText, CopyValue, Refresh } from "./controls";
import { ConsumptionProfileChart } from "./consumption-profile-chart";
import { InfoTip } from "./info-tip";
import styles from "./submission-detail.module.css";
import { ResendConsultationEmail } from "./resend-consultation-email";
import { requireStaff } from "../../lib/auth/server";
import { SubmissionEmailHistory } from "./submission-email-history";
import { SubmissionChanges } from "./submission-changes";

export async function SubmissionDetail({ row, params }: { row: Row; params: Params }) {
  await requireStaff();
  const [t, locale, estimate, previewUrl] = await Promise.all([
    getT(), getLocale(), loadSubmissionEstimate(row), loadCustomerPreviewUrl(row),
  ]);
  const submissionId = row.submission_id || t("未填写");
  const profile = consumptionProfileLabel(row.consumption_profile);
  const en = translator("en");
  const data = record(record(row.payload).data);
  const tallyUrl = safeUrl(data.submissionPreviewUrl), pdfUrl = safeUrl(data.submissionPdfUrl);
  const amount = (value: number) => value.toLocaleString("en-US", { maximumFractionDigits: 2 });
  const historyReturn = contactReturnHref(params);
  return <div className={styles.page}>
    {historyReturn ? <WorkspaceLink prefetch={false} href={historyReturn} className="staff-back"><ArrowLeft size={16} />{t("返回询价统计")}</WorkspaceLink>
      : <Back href={`/submissions?${queryString(parseFilters(params))}`} />}
    <article className={styles.card} aria-labelledby="submission-reference" data-testid="submission-detail-card">
      <header className={styles.heading}>
        <div>
          <p className="staff-kicker">{t("咨询详情")}</p>
          <div className={styles.reference}>
            <h1 id="submission-reference" data-testid="submission-reference">{submissionId}</h1>
            {row.submission_id && <CopyText value={row.submission_id} label="复制提交编号" iconOnly />}
          </div>
        </div>
        <div className={styles.headerActions}>
          <div className={styles.submitted}>
            <span>{t("提交时间（北京时间）")}</span>
            <span>{formatDate(row.submitted_at || row.received_at, locale)}</span>
            {(row.revision || 1) > 1 && <span>{locale === "en" ? "Customer updated" : "客户最近修改"} · {formatDate(row.updated_at, locale)}</span>}
          </div>
          <Refresh />
        </div>
      </header>

      <div className={styles.body}>
        <div className={styles.customer}>
          <section aria-labelledby="submission-contact-title">
            <h2 id="submission-contact-title">{t("联系资料")}</h2>
            <dl className={styles.contact}>
              <div className={styles.email}><dt>{t("联系邮箱")}</dt><dd>
                <span>{row.email || t("未填写")}</span>{row.email && <CopyValue value={row.email} />}
              </dd></div>
              <div><dt>{t("姓名")}</dt><dd>{row.name || t("未填写")}</dd></div>
              <div><dt>{t("电话")}</dt><dd>{row.phone || t("未填写")}</dd></div>
              <div className={styles.country}><dt>{t("国家 / 地区")}</dt><dd>{row.country_name || row.country_code || t("未填写")}</dd></div>
            </dl>
          </section>

          <section className={styles.energySection} aria-labelledby="submission-energy-title">
            <h2 id="submission-energy-title">{t("用电需求")}</h2>
            <div className={styles.energySummary}>
              <dl className={styles.energy}>
                <div><dt>{t("最高月用电量")}</dt><dd data-testid="submission-monthly-kwh">{
                  validMonthlyKwh(row.monthly_kwh) ? `${amount(row.monthly_kwh)} kWh` : t("未提供")
                }</dd></div>
                <div><dt>{t("每日用电模型")}</dt><dd data-testid="submission-energy-profile">{profile ? <>
                  <span lang="zh-CN">{profile}</span><small className={styles.profileEnglish} lang="en">{en(profile)}</small>
                </> : t("未提供")}</dd></div>
              </dl>
              <ConsumptionProfileChart profile={row.consumption_profile} />
            </div>
          </section>
        </div>

        <section className={styles.estimate} aria-labelledby="submission-quote-title" data-testid="submission-estimate">
          <div className={styles.sectionHeading}>
            <h2 id="submission-quote-title">{t("当前参考报价")}</h2>
            <InfoTip label={t("报价计算说明")}>
              <p>{t("按客户已提交的用电需求和最新价格参数计算；价格参数修改后，客户预览和这里的报价都会更新。")}</p>
              {estimate.status === "ready" && <p>{t("价格版本 {version} · 计算时间 {time}（北京时间）", {
                version: estimate.pricingVersion, time: formatDate(estimate.calculatedAt, locale),
              })}</p>}
            </InfoTip>
          </div>
          {estimate.status === "ready" ? <>
            <dl className={styles.results}>
              <div className={styles.total}><dt className={styles.visuallyHidden}>{t("预计报价")}</dt><dd className={styles.price} data-testid="submission-current-quote">EC${amount(estimate.quoteXcd)}</dd></div>
              <div><dt>{t("年节约用电量")}</dt><dd data-testid="submission-annual-savings">{amount(estimate.annualSavedKwh)} <small>{t("度 / 年")}</small></dd></div>
              <div><dt>{t("预计回本周期")}</dt><dd>{estimate.paybackYears === null ? "—" : t("{0} 年", { 0: estimate.paybackYears.toFixed(1) })}</dd></div>
            </dl>
            <dl className={styles.equipment} aria-label={t("推荐配置")}>
              <div><dt>{t("逆变器")}</dt><dd data-testid="submission-inverter">{estimate.inverterKw} kW</dd></div>
              <div><dt>{t("电池")}</dt><dd data-testid="submission-battery">{estimate.batteryKwh} kWh</dd></div>
              <div><dt>{t("组件数量")}</dt><dd data-testid="submission-panels">{estimate.panelCount} × 500 W</dd></div>
            </dl>
          </> : <p className={styles.note} role="status">{t(estimate.status === "missing-inputs"
            ? "这条咨询缺少完整的用电需求，暂无法计算报价。"
            : "报价暂时无法计算，请刷新重试。客户提交内容不受影响。")}</p>}
        </section>
      </div>

      {row.consultation_id && <section className={styles.nativeAnswers} aria-label={locale === "en" ? "Submitted answers" : "提交内容"}>
        <h2>{locale === "en" ? "Installation & additional details" : "安装与补充资料"}</h2>
        <dl><div><dt>{locale === "en" ? "Installation address" : "安装地址"}</dt><dd>{String(record(row.address).full || Object.values(record(row.address)).filter(v => typeof v === "string").join(", ") || "—")}</dd></div>
          {answerEntries(row.answers || {}, locale === "en" ? "en" : "zh").map(([label,value]) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}
        </dl>
      </section>}
      <footer className={styles.actions}>
        {previewUrl ? <a className="staff-button staff-primary" href={previewUrl} target="_blank" rel="noopener noreferrer" data-testid="customer-preview-link">{t("打开客户预览页")}</a>
          : <span className={styles.note}>{t("客户预览链接暂不可用。")}</span>}
        <ResendConsultationEmail id={String(row.id)} email={row.email} available={!!previewUrl} />
        {!row.consultation_id && (tallyUrl || pdfUrl) && <div className={styles.sourceLinks}>
          {tallyUrl && <a href={tallyUrl} target="_blank" rel="noopener noreferrer">{t("打开 Tally 原始预览")}</a>}
          {pdfUrl && <a href={pdfUrl} target="_blank" rel="noopener noreferrer">{t("打开 PDF")}</a>}
        </div>}
      </footer>
    </article>
    {row.consultation_id && <SubmissionEnvironment id={row.consultation_id} locale={locale} />}
    {row.consultation_id && <SubmissionChanges id={row.consultation_id} locale={locale} params={params} />}
    <SubmissionEmailHistory id={String(row.id)} locale={locale} />
  </div>;
}
