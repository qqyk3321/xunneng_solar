import "server-only";
import { nativeDatabase, nativeEnabled } from "./native";
import type { SupabaseClient } from "@supabase/supabase-js";

export type EmailEmployee = { id: string; display_name: string; email: string };

export async function loadEmailEmployees(staff: SupabaseClient): Promise<EmailEmployee[]> {
  const employees: EmailEmployee[] = [];
  for (let offset = 0; ; offset += 200) {
    const result = await staff.from("staff_profiles").select("id,display_name,email")
      .order("email").order("id").range(offset, offset + 199);
    if (result.error) throw Error("Employee list unavailable");
    employees.push(...(result.data ?? []));
    if ((result.data?.length ?? 0) < 200) return employees;
  }
}

export type EmailHistoryFilters = {
  type: "all" | "automatic" | "manual";
  employee: string;
  status: "all" | "accepted" | "failed" | "pending";
  automaticOffset: number;
  manualOffset: number;
};
export type EmailHistoryRow = {
  id: string; type: "automatic" | "manual"; time: string;
  submissionRowId: string; submissionReference: string | null; recipientEmail: string | null;
  status: "accepted" | "failed" | "pending";
  employeeId: string | null; employeeEmail: string | null; employeeName: string | null;
  providerId: string | null; providerStatus: number | null;
};
export type EmailHistoryPage = {
  rows: EmailHistoryRow[]; total: number;
  next: { automaticOffset: number; manualOffset: number } | null;
};
export function parseEmailHistoryFilters(params: URLSearchParams): EmailHistoryFilters {
  const type = params.get("type") || "all", status = params.get("status") || "all";
  const employee = params.get("employee") || "";
  const offset = (key: string) => {
    const value = params.get(key) || "0";
    if (!/^\d{1,7}$/.test(value) || Number(value) > 1000000) throw Error("Invalid filters");
    return Number(value);
  };
  if (!["all", "automatic", "manual"].includes(type) || !["all", "accepted", "failed", "pending"].includes(status)
    || (employee !== "" && !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(employee))) throw Error("Invalid filters");
  return { type: type as EmailHistoryFilters["type"], status: status as EmailHistoryFilters["status"], employee,
    automaticOffset: offset("automaticOffset"), manualOffset: offset("manualOffset") };
}

// Fetch at most 11 rows per source, then merge. Cursor offsets advance only for
// displayed rows, so interleaved sources never skip records at a page boundary.
export async function loadEmailHistory(business: SupabaseClient, staff: SupabaseClient, id: string | null, filters: EmailHistoryFilters): Promise<EmailHistoryPage> {
  if (nativeEnabled()) business = nativeDatabase();
  const automatic = async () => {
    if (filters.type === "manual" || filters.employee) return { data: [], count: 0, error: null };
    let query = business.from(nativeEnabled() ? "consultation_automatic_history" : "consultation_email_audit")
      .select("id,tally_submission_row_id,attempted_at,status,resend_email_id,resend_http_status", { count: "exact" });
    if (id !== null) query = query.eq("tally_submission_row_id", id);
    if (filters.status !== "all") query = query.eq("status", filters.status);
    return query.order("attempted_at", { ascending: false }).order("id", { ascending: false })
      .range(filters.automaticOffset, filters.automaticOffset + 10);
  };
  const manual = async () => {
    if (filters.type === "automatic") return { data: [], count: 0, error: null };
    let query = business.from(nativeEnabled() ? "consultation_manual_history" : "consultation_email_resends")
      .select("request_id,tally_submission_row_id,requested_at,status,requested_by,requested_by_email,resend_email_id,provider_status", { count: "exact" });
    if (id !== null) query = query.eq("tally_submission_row_id", id);
    if (filters.status !== "all") query = query.eq("status", filters.status);
    if (filters.employee) query = query.eq("requested_by", filters.employee);
    return query.order("requested_at", { ascending: false }).order("request_id", { ascending: false })
      .range(filters.manualOffset, filters.manualOffset + 10);
  };
  const [a, m] = await Promise.all([automatic(), manual()]);
  if (a.error || m.error) throw Error("Email history unavailable");
  const rows: EmailHistoryRow[] = [
    ...(a.data ?? []).map(row => ({ id: `automatic:${row.id}`, type: "automatic" as const, time: row.attempted_at,
      submissionRowId: String(row.tally_submission_row_id), submissionReference: null, recipientEmail: null,
      status: row.status, employeeId: null, employeeEmail: null, employeeName: null,
      providerId: row.resend_email_id, providerStatus: row.resend_http_status })),
    ...(m.data ?? []).map(row => ({ id: `manual:${row.request_id}`, type: "manual" as const, time: row.requested_at,
      submissionRowId: String(row.tally_submission_row_id), submissionReference: null, recipientEmail: null,
      status: row.status, employeeId: row.requested_by, employeeEmail: row.requested_by_email, employeeName: null,
      providerId: row.resend_email_id, providerStatus: row.provider_status })),
  ];
  rows.sort((x, y) => Date.parse(y.time) - Date.parse(x.time) || y.type.localeCompare(x.type, "en"));
  const page = rows.slice(0, 10);
  const ids = [...new Set(page.flatMap(row => row.employeeId ? [row.employeeId] : []))];
  if (ids.length) {
    const people = await staff.from("staff_profiles").select("id,display_name").in("id", ids);
    // Retain the email snapshot even when a profile has been renamed or deleted.
    if (!people.error) for (const row of page) row.employeeName = people.data?.find(p => p.id === row.employeeId)?.display_name || null;
  }
  if (id === null && page.length) {
    const submissions = await business.from(nativeEnabled() ? "consultation_records" : "tally_form_submissions").select("id,submission_id,email")
      .in("id", [...new Set(page.map(row => row.submissionRowId))]);
    if (submissions.error) throw Error("Email history unavailable");
    for (const row of page) {
      const submission = submissions.data?.find(s => String(s.id) === row.submissionRowId);
      row.submissionReference = submission?.submission_id ?? null;
      row.recipientEmail = submission?.email ?? null;
    }
  }
  return { rows: page, total: (a.count ?? 0) + (m.count ?? 0), next: rows.length > 10 ? {
    automaticOffset: filters.automaticOffset + page.filter(row => row.type === "automatic").length,
    manualOffset: filters.manualOffset + page.filter(row => row.type === "manual").length,
  } : null };
}
