import "server-only";
import { readFile } from "node:fs/promises";
import { join } from "node:path";
import { requireStaff } from "../auth/server";
import { modelId, type GenerationModel } from "../solution-suggest/models";
import { parseModelTable } from "../solution-suggest/model-table";
import manifest from "../solution-suggest/model-table-manifest.json";
import { FIXED_INSTALLATION, PROFILES, optimizeSystem, type ProfileKey } from "../solution-suggest/optimizer";
import { estimateQuoteXcd, parsePricingValues, PRICING_FIELDS } from "../quote-pricing/model";
import { estimateReturns } from "../quote-pricing/returns";
import { loadPricing } from "../quote-pricing/server";
import { consumptionProfileLabel, validMonthlyKwh } from "./presentation";

// Cache only immutable generation data; read current prices on every request.
let modelPromise: Promise<GenerationModel> | undefined;
function loadModel() {
  return modelPromise ??= readFile(join(process.cwd(), "public", manifest.url.slice(1)), "utf8")
    .then(text => {
      const table = parseModelTable(text, { ...manifest, schemaVersion: 1 });
      const model = table.models.find(item => item.id === modelId(FIXED_INSTALLATION) && item.source === FIXED_INSTALLATION.source);
      if (!model) throw new Error("Missing recommendation model");
      return model;
    }).catch(error => { modelPromise = undefined; throw error; });
}

export type SubmissionEstimate = {
  status: "ready";
  quoteXcd: number;
  inverterKw: number;
  batteryKwh: number;
  panelCount: number;
  annualSavedKwh: number;
  paybackYears: number | null;
  pricingVersion: number;
  calculatedAt: string;
} | { status: "missing-inputs" | "unavailable" };

export async function loadSubmissionEstimate(submission: {
  country_code: string | null; monthly_kwh?: number | null; consumption_profile?: string | null;
}): Promise<SubmissionEstimate> {
  await requireStaff();
  const { monthly_kwh: monthlyKwh, consumption_profile: profile } = submission;
  if (!validMonthlyKwh(monthlyKwh) || !consumptionProfileLabel(profile)) return { status: "missing-inputs" };
  if (submission.country_code !== "AG" && submission.country_code !== "DM") return { status: "unavailable" };
  try {
    const [pricing, model] = await Promise.all([loadPricing(), loadModel()]);
    const plan = optimizeSystem(model, monthlyKwh, PROFILES[profile as ProfileKey].values);
    const prices = parsePricingValues(Object.fromEntries(PRICING_FIELDS.map(field => [field.key, pricing[field.key]])));
    const quoteXcd = estimateQuoteXcd(prices, { ...plan, inverterKw: plan.inverterKw as 5 | 8 | 10 });
    const returns = estimateReturns(plan.months, quoteXcd);
    const local = submission.country_code === "DM" ? returns.dominica : returns.antigua;
    return {
      status: "ready", quoteXcd, inverterKw: plan.inverterKw, batteryKwh: plan.batteryKwh, panelCount: plan.panelCount,
      annualSavedKwh: returns.savedKwh, paybackYears: local.years,
      pricingVersion: pricing.version, calculatedAt: new Date().toISOString(),
    };
  } catch { return { status: "unavailable" }; }
}
