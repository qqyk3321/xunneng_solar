import { createHash, createHmac, timingSafeEqual } from "node:crypto";

// Reproduce the existing webhook link only when it still matches the stored
// authorization record. Never issue, rotate or revive a token while viewing.
export function verifiedCustomerPreviewUrl(
  id: string | number, country: string | null, storedHash: unknown, signingKey: string | undefined,
): string | null {
  if (!/^[1-9]\d{0,18}$/.test(String(id)) || !signingKey
    || !["AG", "DM"].includes(country ?? "")
    || typeof storedHash !== "string" || !/^[0-9a-f]{64}$/.test(storedHash)) return null;
  const token = createHmac("sha256", signingKey).update(`consultation-preview/${id}`).digest("base64url");
  const actual = createHash("sha256").update(token).digest();
  if (!timingSafeEqual(actual, Buffer.from(storedHash, "hex"))) return null;
  return `https://www.solortide.com/${country === "AG" ? "antigua" : "dominica"}/submission/${token}`;
}
