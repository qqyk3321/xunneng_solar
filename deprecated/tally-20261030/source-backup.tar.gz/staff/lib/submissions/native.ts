import "server-only";
import { createClient } from "@supabase/supabase-js";
import { previewPath, previewToken, tokenHash } from "@solortide/consultation-core/tokens";
import type { Row } from "../data";
export const nativeEnabled = () => process.env.NATIVE_CONSULTATION_ENABLED === "true";
export function nativeDatabase() {
  const url = process.env.CONSULTATION_DATABASE_URL?.trim(), key = process.env.CONSULTATION_DATABASE_KEY?.trim();
  if (!nativeEnabled() || !url || !key) throw Error("Native consultation database is not configured");
  if (url.includes("thiqsnscgdjwihcfpomw") && (process.env.CONSULTATION_ENVIRONMENT !== "production" || process.env.VERCEL_ENV !== "production")) throw Error("Production database is disabled in previews");
  return createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false }, global: { fetch: (input, init) => fetch(input, { ...init, cache: "no-store", signal: AbortSignal.timeout(12000) }) } });
}
export async function nativeCustomerUrl(row: Pick<Row, "consultation_id" | "country_code">) {
  if (!row.consultation_id || !row.country_code) return null;
  const secret = process.env.CONSULTATION_TOKEN_SECRET?.trim() || "";
  const hash = tokenHash(previewToken(row.consultation_id, secret));
  const { data, error } = await nativeDatabase().from("consultation_access_tokens").select("expires_at,revoked_at")
    .eq("consultation_id", row.consultation_id).eq("token_hash", hash).maybeSingle();
  if (error || !data || data.revoked_at || (data.expires_at && data.expires_at !== "infinity" && Date.parse(data.expires_at) <= Date.now())) return null;
  const origin = new URL(process.env.CONSULTATION_SITE_URL || "");
  if (origin.protocol !== "https:" && !(process.env.CONSULTATION_ENVIRONMENT === "local" && ["localhost","127.0.0.1"].includes(origin.hostname))) return null;
  return new URL(previewPath(row.consultation_id, row.country_code, secret), origin).href;
}
