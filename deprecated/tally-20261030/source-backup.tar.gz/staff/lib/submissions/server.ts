import "server-only";
import { nativeCustomerUrl } from "./native";
import { db, type Row } from "../data";
import { requireStaff } from "../auth/server";
import { verifiedCustomerPreviewUrl } from "./preview-link";

export async function loadCustomerPreviewUrl(row: Pick<Row, "id" | "country_code" | "consultation_id">) {
  await requireStaff();
  try {
    if (row.consultation_id) return await nativeCustomerUrl(row);
    const { data, error } = await db().from("consultation_preview_tokens")
      .select("token_hash").eq("tally_submission_row_id", row.id).maybeSingle();
    if (error || !data) return null;
    return verifiedCustomerPreviewUrl(row.id, row.country_code, data.token_hash, process.env.SUPABASE_SECRET_KEY?.trim());
  } catch { return null; }
}
