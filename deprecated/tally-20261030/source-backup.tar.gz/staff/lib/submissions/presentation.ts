import { record } from "../query";

export const CONSUMPTION_PROFILES: Record<string, string> = {
  daytime: "白天用电",
  rush: "白天高峰",
  evening: "傍晚高峰",
  night: "夜间高峰",
};

export function consumptionProfileLabel(value: unknown) {
  return typeof value === "string" && Object.hasOwn(CONSUMPTION_PROFILES, value)
    ? CONSUMPTION_PROFILES[value]
    : null;
}

export function validMonthlyKwh(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value) && value > 0 && value <= 1_000_000;
}

// Verified Tally field keys, including the older split-address form. Never match
// labels broadly: "Email address" and unrelated customer answers must survive.
const ADDRESS_FIELDS = new Set([
  "question_rrNGK5", "question_dDLaPr", "question_YME0dN",
  "question_DJrkel", "question_l7oeRo", "question_RJXMRK",
]);

export function submissionAnswers(payload: unknown, monthlyKwh: unknown, profile: unknown) {
  const original = record(payload), data = record(original.data);
  if (!Array.isArray(data.fields)) return payload;
  return { ...original, data: { ...data, fields: data.fields.filter(value => {
    const key = record(value).key;
    if (typeof key !== "string") return true;
    return !ADDRESS_FIELDS.has(key)
      && !(key === "question_4NWAkB" && validMonthlyKwh(monthlyKwh))
      && !(key === "question_PBYLLb" && consumptionProfileLabel(profile));
  }) } };
}
