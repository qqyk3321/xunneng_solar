import "server-only";
import { requireStaff } from "../auth/server";
import { submissionDb, submissionTable } from "../data";
import { nativeEnabled } from "../submissions/native";
const contactTable = () => nativeEnabled() ? "consultation_contact_records" : "consultation_contacts";
import { literalPattern } from "../query";
import { CONTACT_PAGE_SIZE, contactId, type ContactFilters } from "./query";

export type Contact = { id: string; email: string; submission_count: number; latest_submitted_at: string };
export type ContactSubmission = { id: string | number; submission_id: string; submitted_at: string };
const columns = "id,email,submission_count,latest_submitted_at";
const failure = () => new Error("询价统计暂时无法读取，请刷新重试。");

export async function findContacts(filters: ContactFilters) {
  await requireStaff();
  const client = submissionDb();
  function query() {
    let q = client.from(contactTable()).select(columns, { count: "exact" });
    if (filters.email) q = q.filter("email", "imatch", literalPattern(filters.email));
    const ascending = filters.direction === "asc";
    // Sort the stored summaries before pagination, with a unique tie-breaker.
    // Reversing both columns allows each index to serve either direction.
    return q.order(filters.sort === "count" ? "submission_count" : "latest_submitted_at", { ascending })
      .order("id", { ascending: !ascending });
  }
  let result = await query().range((filters.page - 1) * CONTACT_PAGE_SIZE, filters.page * CONTACT_PAGE_SIZE - 1);
  if (result.error) throw failure();
  const count = result.count ?? 0, pages = Math.max(1, Math.ceil(count / CONTACT_PAGE_SIZE)), page = Math.min(filters.page, pages);
  if (page !== filters.page) {
    result = await query().range((page - 1) * CONTACT_PAGE_SIZE, page * CONTACT_PAGE_SIZE - 1);
    if (result.error) throw failure();
  }
  return { rows: (result.data ?? []) as Contact[], count, pages, page };
}

export async function loadContactHistory(id: string, requestedPage: number) {
  await requireStaff();
  if (!contactId.test(id)) return null;
  const client = submissionDb();
  const summary = await client.from(contactTable()).select(columns).eq("id", id).maybeSingle();
  if (summary.error) throw failure();
  if (!summary.data) return null;
  const contact = summary.data as Contact;
  const count = contact.submission_count, pages = Math.max(1, Math.ceil(count / CONTACT_PAGE_SIZE)), page = Math.min(requestedPage, pages);
  // The stored count comes from the write-time index. Only this email's page of
  // original records is read; no client grouping or whole-history aggregation.
  const history = await client.from(submissionTable())
    .select("id,submission_id,submitted_at").eq("email_key", contact.email)
    .order("submitted_at", { ascending: false }).order("id", { ascending: false })
    .range((page - 1) * CONTACT_PAGE_SIZE, page * CONTACT_PAGE_SIZE - 1);
  if (history.error) throw failure();
  return { contact, rows: (history.data ?? []) as ContactSubmission[], count, pages, page };
}
