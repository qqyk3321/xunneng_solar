import "server-only";
import { nativeDatabase, nativeEnabled } from "./submissions/native";
export const submissionTable = () => nativeEnabled() ? "consultation_records" : "tally_form_submissions";
export const submissionDb = () => nativeEnabled() ? nativeDatabase() : db();
import { createClient } from "@supabase/supabase-js";
import { requireStaff } from "./auth/server";
import {
  dateBounds,
  literalPattern,
  PAGE_SIZE,
  record,
  type Filters,
  type Kind,
} from "./query";

export type Row = {
  id: string | number;
  consultation_id?: string | null;
  source?: "native" | "legacy_tally";
  answers?: Record<string, unknown>;
  schema_version?: number;
  revision?: number;
  updated_at?: string;
  email: string;
  country_code: string | null;
  country_name: string | null;
  name?: string;
  phone?: string;
  submission_id?: string;
  monthly_kwh?: number | null;
  consumption_profile?: string | null;
  form_id?: string;
  submitted_at?: string;
  received_at?: string;
  created_at?: string;
  message?: string;
  address?: unknown;
  payload?: unknown;
  content?: unknown;
  images?: unknown;
  format?: string;
};
const tables = {
  submissions: "tally_form_submissions",
  inquiries: "anonymous_inquiries_preview",
};
const columns = {
  submissions:
    "id,name,email,phone,country_code,country_name,submission_id,submitted_at,received_at",
  inquiries: "id,email,country_code,country_name,created_at,message,format",
};
export function db() {
  const url = process.env.SUPABASE_URL,
    key = process.env.SUPABASE_SECRET_KEY;
  if (!url || !key)
    throw new Error("请配置子项目的 SUPABASE_URL 和 SUPABASE_SECRET_KEY。");
  return createClient(url, key, {
    auth: { autoRefreshToken: false, persistSession: false },
    global: {
      fetch: (input, init) => fetch(input, { ...init, cache: "no-store" }),
    },
  });
}
export async function findRows(kind: Kind, f: Filters) {
  await requireStaff();
  const bounds = dateBounds(f),
    time = kind === "submissions" ? "submitted_at" : "created_at";
  const client = kind === "submissions" ? submissionDb() : db();
  function request(head = false) {
    let q = client
      .from(kind === "submissions" ? submissionTable() : tables[kind])
      .select(columns[kind], { count: "exact", head });
    if (bounds.from) q = q.gte(time, bounds.from);
    if (bounds.to) q = q.lt(time, bounds.to);
    if (f.email)
      q = q.filter(
        "email",
        "imatch",
        `${f.emailMode === "exact" ? "^" : ""}${literalPattern(f.email)}${f.emailMode === "exact" ? "$" : ""}`,
      );
    if (f.country === "unknown") q = q.is("country_code", null);
    else if (f.country) q = q.eq("country_code", f.country);
    if (kind === "submissions" && f.submissionId)
      q = q.eq("submission_id", f.submissionId);
    if (f.q) {
      const pattern = JSON.stringify(literalPattern(f.q));
      q =
        kind === "inquiries"
          ? q.filter("message", "imatch", literalPattern(f.q))
          : q.or(
              ["name", "phone", "submission_id"]
                .map((c) => `${c}.imatch.${pattern}`)
                .join(","),
            );
    }
    return q;
  }
  const countResult = await request(true);
  if (countResult.error)
    throw new Error("数据库查询失败，请检查连接和读取权限。");
  const count = countResult.count ?? 0,
    pages = Math.max(1, Math.ceil(count / PAGE_SIZE)),
    page = Math.min(f.page, pages);
  let q = request().order(f.sort === "email" ? "email" : time, {
    ascending: f.direction === "asc",
    nullsFirst: false,
  });
  if (f.sort === "email") q = q.order(time, { ascending: false });
  const result = await q
    .order("id", { ascending: f.direction === "asc" })
    .range((page - 1) * PAGE_SIZE, page * PAGE_SIZE - 1);
  if (result.error) throw new Error("数据库查询失败，请稍后重试。");
  return { rows: (result.data ?? []) as unknown as Row[], count, page, pages };
}
export async function getRow(kind: Kind, id: string) {
  await requireStaff();
  const extra =
    kind === "submissions" ? ",form_id,payload,monthly_kwh,consumption_profile" : ",content,images";
  const { data, error } = await (kind === "submissions" ? submissionDb() : db())
    .from(kind === "submissions" ? submissionTable() : tables[kind])
    .select(columns[kind] + extra + (kind === "submissions" && nativeEnabled() ? ",consultation_id,source,answers,schema_version,address" : ""))
    .eq("id", id)
    .maybeSingle();
  if (error) throw new Error("数据库查询失败，请稍后重试。");
  return data as unknown as Row | null;
}
export const uuid =
  /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
export async function photosFor(row: Row) {
  await requireStaff();
  const images = Array.isArray(row.images) ? row.images : [];
  const photos = images.slice(0, 3).flatMap((value, index) => {
    const image = record(value),
      path = typeof image.path === "string" ? image.path : "";
    const ext = (
      {
        "image/webp": "webp",
        "image/png": "png",
        "image/jpeg": "jpg",
      } as Record<string, string>
    )[String(image.mime)];
    const parts = path.split("/");
    if (
      !ext ||
      parts.length !== 3 ||
      parts[0] !== String(row.id) ||
      !uuid.test(parts[1]) ||
      parts[2] !== `${index}.${ext}` ||
      typeof image.bytes !== "number" ||
      !Number.isInteger(image.bytes) ||
      image.bytes <= 0 ||
      image.bytes > 1536 * 1024 ||
      (image.id != null && !uuid.test(String(image.id)))
    )
      return [];
    return [
      { id: typeof image.id === "string" ? image.id : `legacy-${index}`, path },
    ];
  });
  if (!photos.length) return { photos: [], missing: images.length };
  const { data, error } = await db()
    .storage.from("anonymous-inquiry-images-preview")
    .createSignedUrls(
      photos.map((p) => p.path),
      3600,
    );
  const signed = photos.map((p) => ({
    id: p.id,
    url: error
      ? undefined
      : data?.find((item) => item.path === p.path)?.signedUrl ?? undefined,
  }));
  return {
    photos: signed,
    missing: images.length - signed.filter((p) => p.url).length,
  };
}
